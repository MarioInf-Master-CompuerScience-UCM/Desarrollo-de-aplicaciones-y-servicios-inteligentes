Para ejecutar el chatot:
	cd scripts/xnix
	./template-y.sh

Para crear una plantilla inicial:
	python3 -m programy.admin.tool download template-y