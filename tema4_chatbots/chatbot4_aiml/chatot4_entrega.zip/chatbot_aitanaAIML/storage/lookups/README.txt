Lookup Folder
===========

This folder typicall contains the 5 lookup files

    gender.txt
    person.txt
    person2.txt
    normal.txt
    denormal.txt