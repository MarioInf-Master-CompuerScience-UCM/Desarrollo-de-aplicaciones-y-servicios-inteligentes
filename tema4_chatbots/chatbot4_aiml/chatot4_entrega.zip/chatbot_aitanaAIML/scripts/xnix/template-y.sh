#! /bin/sh

clear

python3 -m programy.clients.events.console.client --config ../../config/xnix/config.yaml --cformat yaml --logging ../../config/xnix/logging.yaml

