Test Folder
===========

If you plan of writing unit tests then store them in this folder

To stop module polution its best to keep the folder name different from the module name of the app, however
underneath this folder, the director structure should ideally mirror that within src/templatey